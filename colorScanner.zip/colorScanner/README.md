The Color Scanner application is designed with the target users of those with little to no vision in mind.
One can demonstrate the app's functionality by running the code through the Android Studio emulator.
The application opens to a home screen that gives the user the option to see their favorite or most recent scans, and to scan an object.
When running the emulator it opens to the android camera with a provided image to simulate using a camera in a living room type setting. (t1)
The application scans the area / object and provides the result of the most prominent color. (t2)
From there the user can save the scan, return to the home screen, or scan another object. (t3)
Earlier iterations of the project desired possibilities of a matching function or a unique palette system within favorites, but time constraints and workloads of other courses for team members prevented those extra functions. 

Sources:
inspirtation / guidance for camera launch: https://stackoverflow.com/questions/13977245/android-open-camera-from-button 
